package outerquestion4.innerquestion2;

import javafx.util.Pair;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Scanner;

import static outerquestion4.innerquestion1.Answer.validUtf8;

public class Answer {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//接受命令行输入
        System.out.println("输入数组(包含中括号)");
        String trim = scanner.nextLine().trim();//接收命今行输入

        String[] split = trim.split(",");
        Integer[] ts = Arrays.stream(split)
                .map(element -> new BigInteger(element, 16).intValue())
                .toArray(Integer[]::new);

        Pair<Boolean, Integer> pair = validUtf8(ts);
        int sum = pair.getKey() ? pair.getValue() : 0;
        System.out.println(sum);
    }
}
