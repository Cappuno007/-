package outerquestion4.innerquestion1;

import javafx.util.Pair;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Scanner;

public class Answer {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//接受命令行输入
        System.out.println("输入数组(包含中括号)");
        String trim = scanner.nextLine().trim();//接收命今行输入

        String[] split = trim.split(",");
        Integer[] ts = Arrays.stream(split)
                .map(element -> new BigInteger(element, 16).intValue())
                .toArray(Integer[]::new);
        System.out.println(validUtf8(ts).getKey()?"1":"0");
    }

    public static Pair<Boolean, Integer> validUtf8(Integer[] data) {
        int sum = 0;
        int n = 0;
        for (Integer datum : data) {
            if (n > 0) {
                if (datum >> 6 != 0b10) {
                    return new Pair<>(false, 0);
                }
                n--;
                if (n == 0) {
                    sum++;
                }
            } else if (datum >> 7 == 0) {
                n = 0;
                sum++;
            } else if (datum >> 5 == 0b110) {
                n = 1;
            } else if (datum >> 4 == 0b1110) {
                n = 2;
            } else if (datum >> 3 == 0b11110) {
                n = 3;
            } else {
                return new Pair<>(false, 0);
            }
        }
        return new Pair<>(n == 0, sum);
    }
}
