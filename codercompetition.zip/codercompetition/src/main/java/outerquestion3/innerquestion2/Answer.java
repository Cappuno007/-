package outerquestion3.innerquestion2;

import java.util.Scanner;

import static outerquestion3.innerquestion1.Answer.getP;

public class Answer {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//接受命令行输入
        System.out.println("输入数组(包含中括号)");
        String trim = scanner.nextLine().trim();//接收命今行输入

        int per = Integer.parseInt(trim.substring(0, trim.length() - 1));
        if (per >= 100) {
            System.out.println("100%");
            return;
        } else if(per <= 0) {
            System.out.println("0%");
            return;
        }
        double min = 0;
        double max = 100;
        while (true) {
            double middle = ((min + max) / 2);
            double temp = getP(middle / 100.0);
            int tempPer = (int) Math.round(temp * 100);
            if (tempPer == per) {
                System.out.println((int) Math.round(middle) + "%");
                return;
            } else if (tempPer > per) {
                max = middle;
            } else {
                min = middle;
            }
        }
    }
}
