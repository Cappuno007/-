package outerquestion3.innerquestion1;

import java.util.Scanner;

public class Answer {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//接受命令行输入
        System.out.println("输入数组(包含中括号)");
        String trim = scanner.nextLine().trim();//接收命今行输入

        double c = Double.parseDouble(trim.substring(0, trim.length() - 1)) / 100;
        if (c >= 1) {
            System.out.println("100%");
            return;
        } else if(c <= 0) {
            System.out.println("0%");
            return;
        }
        double temp = getP(c);
        System.out.println((int) Math.round(temp * 100) + "%");
    }

    public static double getP(double c) {
        int count = (int) Math.ceil(1 / c);
        double temp = 1;
        double last = 0;
        double sum = 0;
        for (int i = 1; i <= count; i++) {
            temp -= last;
            last = temp * Math.min(1, c * i);
            sum += last * i;
        }
        return 1 / sum;
    }

}
