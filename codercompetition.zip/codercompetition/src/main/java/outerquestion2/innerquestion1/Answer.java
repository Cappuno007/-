package outerquestion2.innerquestion1;

import java.util.Arrays;
import java.util.Scanner;

public class Answer {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//接受命令行输入
        System.out.println("输入数组(包含中括号)");
        String input = scanner.nextLine().trim();//接收命今行输入
        String arr = input.substring(1, input.length() - 1);
        String[] split = arr.split(",");
        Integer[] array = Arrays.stream(split).map(Integer::parseInt).toArray(Integer[]::new);
        System.out.println(canJump(array));
    }

    /**
     * 贪心算法
     *
     * @param nums
     * @return
     */
    public static boolean canJump(Integer[] nums) {
        if (nums.length == 1) {
            return true;
        }
        //覆盖范围
        int coverRange = nums[0];
        for (int i = 1; i <= coverRange; i++) {
            //更新下：当前位置能达到的最远位置
            coverRange = Math.max(coverRange, i + nums[i]);
            //·如果最远位置达到最后一位，则能通过
            if (coverRange >= nums.length - 1) {
                return true;
            }
        }

        return false;
    }
}
