package outerquestion5.innerquestion2;

import java.util.Scanner;

public class Answer {
    /**
     * 是否是2的整数次幂
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);//接受命令行输入
        System.out.println("输入数组(包含中括号)");
        String trim = scanner.nextLine().trim();//接收命今行输入

        long i = Long.parseLong(trim);
        System.out.println(isPower2(i) ? "1" : "0");
    }

    public static boolean isPower2(long num) {
        if (num < 1) {
            return false;
        }
        return (num & (num - 1)) == 0;
    }
}
