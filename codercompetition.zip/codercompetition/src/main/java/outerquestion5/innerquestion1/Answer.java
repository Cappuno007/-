package outerquestion5.innerquestion1;

public class Answer {


    /**
     * 十进制转二进制
     */
    public static void main(String[] args) {
        //十进制转二进制
//        System.out.println(Integer.toBinaryString(xxx));
    }

}
