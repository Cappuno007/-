package outerquestion1.innerquestion2;

import java.math.BigInteger;

public class Answer {


    /**
     * ZigZag解码16进制
     */
    public static void main(String[] args) {
//        -20211106
//        -1024
//        -5566
//        2333
//        123
//        321
        // 解码
        System.out.println(zigzagToInt(0x268cb43));
        System.out.println(zigzagToInt(0x7ff));
        System.out.println(zigzagToInt(0x2b7b));
        System.out.println(zigzagToInt(0x123a));
        System.out.println(zigzagToInt(0xf6));
        System.out.println(zigzagToInt(0x282));
    }

    public static int zigzagToInt(int n) {
        return (n >>> 1) ^ -(n & 1);
    }
}
