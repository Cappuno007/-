package com.competition.myproject.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.competition.myproject.domain.User;
import com.competition.myproject.service.UserService;
import com.competition.myproject.mapper.UserMapper;
import org.springframework.stereotype.Service;

/**
 *
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
        implements UserService {

    @Override
    public User login(User user) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(User::getRoleName, user.getRoleName()).eq(User::getPassword, user.getPassword());
        User one = getOne(queryWrapper);
        return one;
    }
}




