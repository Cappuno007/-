package com.competition.myproject.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName player_roles
 */
@TableName(value ="player_roles")
@Data
public class User implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Long nId;

    /**
     * 
     */
    private String sRoleName;

    /**
     * 
     */
    private String sPassword;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}