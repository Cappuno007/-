package com.competition.myproject.config;

/**
 * Created by wangruoduo on 2021/10/25.
 */
public class Constants {
    /**
     * 成功
     */
    public static final int SUCCESS = 0;
    /**
     * 失败
     */
    public static final int FAIL = 1;
}
