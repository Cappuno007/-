package com.competition.myproject.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.competition.myproject.domain.User;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @Entity com.competition.myproject.domain1.User
 */
public interface UserMapper extends BaseMapper<User> {

    @Override
    int insert(User entity);

    @Select("select t1.*,t2.n_score from player_roles t1 LEFT JOIN  player_score t2  ON t1.n_id =t2.n_id WHERE t1.n_id= #{id}")
    List<Map<String,Object>> select( int id);

    @Select("select t1.*,t2.n_score from player_roles t1 LEFT JOIN  player_score t2  ON t1.n_id =t2.n_id WHERE t1.n_id= #{id}")
    List<User> select1( int id);
}




