package com.competition.myproject.mapper;

import com.competition.myproject.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.competition.myproject.domain1.User
 */
public interface UserMapper extends BaseMapper<User> {

    @Override
    int insert(User entity);
}




