package com.competition.myproject.controller;

import com.competition.myproject.config.Constants;
import com.competition.myproject.config.Msg;
import com.competition.myproject.domain.User;
import com.competition.myproject.model.Result;
import com.competition.myproject.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by wangruoduo on 2021/10/25.
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public Result login(User user, HttpServletResponse response) {

//        DigestUtils.md5Digest()

        User realUser = userService.login(user);
        Result result = new Result();
        if (realUser == null) {
            result.setCode(Constants.FAIL);
            result.setMsg(Msg.MSG_1);
        } else {
            result.setCode(Constants.SUCCESS);
            result.setObj(realUser.getNId());

            Cookie cookie = new Cookie("loginId", String.valueOf(realUser.getNId()));
            cookie.setMaxAge(60 * 30);
            cookie.setPath("/");
            response.addCookie(cookie);
        }


        return result;
    }

    @PostMapping("/checkCookie")
    public Result checkCookie(@CookieValue(value = "loginId", defaultValue = "") String loginId) {
        Result result = new Result();
        if (StringUtils.isBlank(loginId)) {
            result.setCode(Constants.FAIL);
            result.setMsg(Msg.MSG_2);
        }else {
            result.setCode(Constants.SUCCESS);
            result.setObj(loginId);
        }

        return result;
    }
}
