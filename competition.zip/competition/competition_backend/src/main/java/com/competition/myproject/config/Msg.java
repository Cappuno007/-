package com.competition.myproject.config;

/**
 * Created by wangruoduo on 2021/10/25.
 */
public class Msg {
    public static final String MSG_1 = "用户名或密码错误";
    public static final String MSG_2 = "用户未登录";
}
