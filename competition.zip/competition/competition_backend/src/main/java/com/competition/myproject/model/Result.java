package com.competition.myproject.model;

import lombok.Data;

/**
 * Created by wangruoduo on 2021/10/25.
 */
@Data
public class Result {

    private int code;
    private String msg;
    private Object obj;
}
