package com.competition.myproject;

import com.competition.myproject.domain.User;
import com.competition.myproject.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

@SpringBootTest
class CompetitionApplicationTests {

    @Autowired
    private UserMapper userMapper;

    @Test
    void insert() {
        User user = new User();
        user.setPassword("789");
        user.setRoleName("123");
        userMapper.insert(user);
    }

    @Test
    void select() {
        List<Map<String, Object>> select = userMapper.select(1);
        System.out.println("11111111");
    }

    @Test
    void select1() {
        List<User> select = userMapper.select1(1);
        System.out.println("11111111");
    }
}
