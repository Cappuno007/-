package com.competition.myproject;

import com.competition.myproject.domain.User;
import com.competition.myproject.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompetitionApplicationTests {

    @Autowired
    private UserMapper userMapper;

    @Test
    void insert() {
        User user = new User();
        user.setSPassword("123");
        user.setSRoleName("456");
        userMapper.insert(user);
    }

}
